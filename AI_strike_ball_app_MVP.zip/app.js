const video = document.getElementById("video");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");
const result = document.getElementById("result");
const statusEl = document.getElementById("status");
const history = document.getElementById("history");

let model = null;
let stream = null;
let running = false;
let lastCenter = null;
let lastCrossed = false;
let lastDecisionTime = 0;

const sliders = ["x","y","w","h","decision"].map(id => document.getElementById(id));
sliders.forEach(s => s.addEventListener("input", drawOverlay));

function zone() {
  return {
    x: Number(document.getElementById("x").value) / 100,
    y: Number(document.getElementById("y").value) / 100,
    w: Number(document.getElementById("w").value) / 100,
    h: Number(document.getElementById("h").value) / 100
  };
}

function drawOverlay(ball=null) {
  if (!video.videoWidth) return;
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const z = zone();
  const zx=z.x*canvas.width, zy=z.y*canvas.height;
  const zw=z.w*canvas.width, zh=z.h*canvas.height;
  const dy=zy+(Number(document.getElementById("decision").value)/100)*zh;

  ctx.lineWidth=4;
  ctx.strokeStyle="#ffffff";
  ctx.fillStyle="rgba(34,197,94,.18)";
  ctx.fillRect(zx,zy,zw,zh);
  ctx.strokeRect(zx,zy,zw,zh);

  ctx.beginPath(); ctx.moveTo(zx,dy); ctx.lineTo(zx+zw,dy);
  ctx.strokeStyle="#f59e0b"; ctx.lineWidth=3; ctx.stroke();

  if(ball){
    ctx.beginPath();
    ctx.arc(ball.x,ball.y,Math.max(8,ball.r),0,Math.PI*2);
    ctx.strokeStyle="#ef4444"; ctx.lineWidth=3; ctx.stroke();
  }
}

function insideAtDecision(x,y) {
  const z=zone();
  const zx=z.x*canvas.width, zy=z.y*canvas.height;
  const zw=z.w*canvas.width, zh=z.h*canvas.height;
  const dy=zy+(Number(document.getElementById("decision").value)/100)*zh;
  return x>=zx && x<=zx+zw && y>=zy && y<=zy+zh && Math.abs(y-dy)<Math.max(12,zh*.06);
}

function addHistory(text, cls) {
  const li=document.createElement("li");
  li.textContent=`${new Date().toLocaleTimeString()} — ${text}`;
  li.className=cls;
  history.prepend(li);
  while(history.children.length>15) history.lastChild.remove();
}

function decide(isStrike) {
  const now=performance.now();
  if(now-lastDecisionTime<900) return;
  lastDecisionTime=now;
  result.textContent=isStrike?"STRIKE":"BALL";
  result.style.background=isStrike?"#15803d":"#b91c1c";
  addHistory(isStrike?"STRIKE":"BALL",isStrike?"history-strike":"history-ball");
}

async function loadModel() {
  statusEl.textContent="AIモデルを読み込んでいます…";
  model=await cocoSsd.load({base:"lite_mobilenet_v2"});
  statusEl.textContent="AIモデル準備完了";
}

async function startCamera() {
  if(!model) await loadModel();
  stream=await navigator.mediaDevices.getUserMedia({
    audio:false,
    video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}}
  });
  video.srcObject=stream;
  await video.play();
  running=true;
  lastCenter=null;
  document.getElementById("startBtn").disabled=true;
  document.getElementById("stopBtn").disabled=false;
  result.textContent="READY";
  result.style.background="#111827";
  statusEl.textContent="AI判定中…";
  detectLoop();
}

function stopCamera() {
  running=false;
  if(stream) stream.getTracks().forEach(t=>t.stop());
  stream=null;
  video.srcObject=null;
  document.getElementById("startBtn").disabled=false;
  document.getElementById("stopBtn").disabled=true;
  result.textContent="CAMERA OFF";
  result.style.background="#111827";
  statusEl.textContent="停止しました";
  ctx.clearRect(0,0,canvas.width,canvas.height);
}

async function detectLoop() {
  if(!running) return;
  try {
    const predictions=await model.detect(video);
    const balls=predictions.filter(p=>p.class==="sports ball" && p.score>=0.35);
    let best=balls.sort((a,b)=>b.score-a.score)[0];
    if(best){
      const [bx,by,bw,bh]=best.bbox;
      const center={x:bx+bw/2,y:by+bh/2,r:Math.max(bw,bh)/2};
      drawOverlay(center);

      if(lastCenter){
        const decisionY = zone().y*canvas.height +
          (Number(document.getElementById("decision").value)/100)*zone().h*canvas.height;

        // 上→下方向に判定線を横切ったときだけ判定
        const crossed = lastCenter.y < decisionY && center.y >= decisionY;
        if(crossed && !lastCrossed){
          decide(insideAtDecision(center.x, decisionY));
          lastCrossed=true;
          setTimeout(()=>lastCrossed=false,700);
        }
      }
      lastCenter=center;
    } else {
      drawOverlay();
    }
  } catch(e) {
    statusEl.textContent="AI処理エラー: "+e.message;
  }
  requestAnimationFrame(detectLoop);
}

document.getElementById("startBtn").addEventListener("click", async()=>{
  try { await startCamera(); }
  catch(e){ statusEl.textContent="カメラを開始できません: "+e.message; }
});
document.getElementById("stopBtn").addEventListener("click",stopCamera);
document.getElementById("resetBtn").addEventListener("click",()=>{
  history.innerHTML="";
  lastCenter=null; lastCrossed=false;
  result.textContent=running?"READY":"CAMERA OFF";
  result.style.background="#111827";
});
window.addEventListener("resize",()=>drawOverlay());
